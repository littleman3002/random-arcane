/* Arcane Hand — creatures v2. Detailed multi-part models (3–7k tris near, ~0.4k far), limb-tagged and animated in the
   vertex shader (gait, arms, wings, crawl, tail, breathing, hit flinch, death). Per-part roughness/metalness, rim light.
   One InstancedMesh per type per LOD: ~18 draw calls for any crowd size. */
(function () {
'use strict';
const R = globalThis.AHR, T = R.T;
let DET = 1; // 1 = near detail, 0 = far / crowd
const sph = (big) => DET ? (big ? new THREE.SphereGeometry(1, 14, 10) : new THREE.SphereGeometry(1, 8, 6)) : new THREE.SphereGeometry(1, 6, 4);
const E = (x, y, z, sx, sy, sz, c, ex = {}) => Object.assign({ g: sph(Math.max(sx, sy, sz) > 0.07), m: T(x, y, z, ex.rx || 0, ex.ry || 0, ex.rz || 0, sx, sy, sz), c }, ex);
const CONE = (x, y, z, r, h, c, rx = 0, ry = 0, rz = 0, ex = {}) => Object.assign({ g: new THREE.ConeGeometry(r, h, DET ? 8 : 4), m: T(x, y, z, rx, ry, rz), c }, ex);
const BOX = (x, y, z, sx, sy, sz, c, ex = {}) => Object.assign({ g: new THREE.BoxGeometry(sx, sy, sz), m: T(x, y, z, ex.rx || 0, ex.ry || 0, ex.rz || 0), c }, ex);
const TOR = (x, y, z, r, t, c, ex = {}) => Object.assign({ g: new THREE.TorusGeometry(r, t, DET ? 8 : 4, DET ? 24 : 10), m: T(x, y, z, ex.rx || 0, ex.ry || 0, ex.rz || 0, ex.sx || 1, ex.sy || 1, ex.sz || 1), c }, ex);
function seg(a, b, r0, r1, c, ex = {}) { // limb segment between two points; pivot = start
  const A = new THREE.Vector3(...a), B = new THREE.Vector3(...b), d = B.clone().sub(A), L = d.length();
  const g = new THREE.CylinderGeometry(r1, r0, L, DET ? 9 : 4); g.translate(0, L / 2, 0);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
  return Object.assign({ g, m: new THREE.Matrix4().compose(A, q, new THREE.Vector3(1, 1, 1)), c, pivot: a }, ex);
}
const L = (limb, pivot, ex = {}) => Object.assign({ limb, pivot }, ex);
const G = (glow, ex = {}) => Object.assign({ glow }, ex);
const CHITIN = { r: 0.32, mt: 0.12 }, METAL = { r: 0.28, mt: 0.9 }, SKIN = { r: 0.78 }, FUR = { r: 0.9 };

const MODELS = {
  grub() { const p = [], body = [0x9A7E8E, 0x8C7080], plate = 0x5A3E50;
    const segs = [[0.34, 0.23], [0.12, 0.27], [-0.1, 0.28], [-0.32, 0.25], [-0.52, 0.19]];
    segs.forEach(([z, r], k) => { const lb = 11 + Math.min(3, k), pv = [0, 0, z];
      p.push(E(0, r * 0.95, z, r, r * 0.9, r * 0.95, body[k % 2], L(lb, pv, SKIN)), E(0, r * 0.55, z, r * 1.02, r * 0.45, r * 0.85, 0xCBB2AA, L(lb, pv, SKIN)),
        E(0, r * 1.25, z, r * 0.9, r * 0.42, r * 0.8, plate, L(lb, pv, CHITIN)), CONE(0, r * 1.75, z - 0.02, 0.035, 0.12, 0x3A2432, -0.35, 0, 0, L(lb, pv, CHITIN)));
      for (const s of [-1, 1]) p.push(CONE(s * r * 0.8, r * 0.3, z, 0.04, 0.16, plate, 0, 0, s * 2.5, L(lb, pv, CHITIN))); });
    const H = [0, 0.24, 0.46];
    p.push(E(0, 0.25, 0.58, 0.19, 0.17, 0.19, 0x6A4A58, L(5, H, SKIN)), E(0, 0.3, 0.56, 0.17, 0.09, 0.16, plate, L(5, H, CHITIN)));
    for (const s of [-1, 1]) { p.push(CONE(s * 0.08, 0.19, 0.74, 0.03, 0.17, 0x2A1E22, Math.PI / 2 + 0.2, 0, -s * 0.55, L(5, H, CHITIN)));
      for (let k = 0; k < 3; k++) p.push(E(s * (0.07 + k * 0.025), 0.31 + k * 0.02, 0.7 - k * 0.03, 0.028, 0.028, 0.028, 0xFFD86A, L(5, H, G(1.4))));
      p.push(seg([s * 0.06, 0.38, 0.62], [s * 0.18, 0.6, 0.8], 0.012, 0.008, 0x3A2432, L(5, H)), E(s * 0.18, 0.6, 0.8, 0.025, 0.025, 0.025, 0xC8A0FF, L(5, H, G(1.2)))); }
    return p; },
  skitter() { const p = [E(0, 0.2, 0.08, 0.15, 0.11, 0.17, 0x2E2A35, CHITIN), E(0, 0.27, -0.22, 0.21, 0.18, 0.26, 0x3A2E48, CHITIN),
      E(0, 0.4, -0.24, 0.05, 0.03, 0.09, 0xB060FF, G(1.6)), E(0, 0.39, -0.12, 0.035, 0.02, 0.05, 0xB060FF, G(1.6))];
    for (let k = 0; k < 3; k++) p.push(TOR(0, 0.27, -0.12 - k * 0.1, 0.19 - k * 0.025, 0.012, 0x6A3A8A, { rx: 0, ry: 0, sx: 1, sy: 0.95, sz: 1 }));
    for (const s of [-1, 1]) { p.push(CONE(s * 0.04, 0.12, 0.23, 0.02, 0.1, 0xD8D0C0, Math.PI, 0, 0, CHITIN));
      p.push(E(s * 0.04, 0.26, 0.24, 0.024, 0.024, 0.024, 0xFF3A2A, G(1.8)), E(s * 0.08, 0.25, 0.22, 0.016, 0.016, 0.016, 0xFF3A2A, G(1.8)), E(s * 0.025, 0.29, 0.2, 0.014, 0.014, 0.014, 0xFF3A2A, G(1.8))); }
    for (let k = 0; k < 4; k++) for (const s of [-1, 1]) { const z = 0.16 - k * 0.09, limb = ((k + (s > 0 ? 1 : 0)) % 2) ? 15 : 16;
      const hip = [s * 0.1, 0.2, z], knee = [s * 0.3, 0.36, z * 1.25 + 0.02], ankle = [s * 0.44, 0.14, z * 1.55], foot = [s * 0.48, 0, z * 1.7];
      p.push(seg(hip, knee, 0.024, 0.02, 0x221E28, L(limb, hip, CHITIN)), E(...knee, 0.024, 0.024, 0.024, 0x3A3445, L(limb, hip, CHITIN)),
        seg(knee, ankle, 0.02, 0.015, 0x221E28, L(limb, hip, CHITIN)), seg(ankle, foot, 0.015, 0.006, 0x4A3A5A, L(limb, hip, CHITIN))); }
    return p; },
  dasher() { const fur = 0x7A2E24, dark = 0x3A1410, belly = 0xB0704A, H = [0, 0.68, 0.36];
    const p = [E(0, 0.6, 0.16, 0.2, 0.22, 0.24, fur, FUR), E(0, 0.56, -0.2, 0.17, 0.18, 0.26, fur, FUR), E(0, 0.5, -0.02, 0.15, 0.12, 0.34, belly, FUR),
      E(0, 0.7, 0.32, 0.12, 0.13, 0.13, fur, L(5, H, FUR))];
    for (let k = 0; k < 7; k++) { const a = (k / 6 - 0.5) * 2.4; p.push(CONE(Math.sin(a) * 0.15, 0.72 + Math.cos(a) * 0.08, 0.26, 0.05, 0.2, dark, -0.9, 0, -Math.sin(a) * 0.6, FUR)); }
    for (let k = 0; k < 5; k++) p.push(CONE(0, 0.8 - k * 0.015, 0.1 - k * 0.12, 0.028, 0.12, 0xFF7A2A, -0.5, 0, 0, G(0.9, CHITIN)));
    p.push(E(0, 0.76, 0.47, 0.13, 0.12, 0.15, fur, L(5, H, FUR)), E(0, 0.72, 0.63, 0.07, 0.065, 0.13, 0x8A3A2A, L(5, H, FUR)), E(0, 0.745, 0.745, 0.025, 0.02, 0.02, 0x101010, L(5, H, CHITIN)),
      E(0, 0.665, 0.6, 0.06, 0.03, 0.11, dark, L(5, H, FUR)));
    for (const s of [-1, 1]) { p.push(CONE(s * 0.08, 0.9, 0.44, 0.045, 0.14, dark, -0.25, 0, s * 0.35, L(5, H, FUR)), E(s * 0.065, 0.785, 0.58, 0.028, 0.02, 0.025, 0xFFB03A, L(5, H, G(1.8))));
      for (let k = 0; k < 2; k++) p.push(CONE(s * (0.025 + k * 0.03), 0.67, 0.68 - k * 0.05, 0.012, 0.05, 0xF0E8D8, Math.PI, 0, 0, L(5, H))); }
    const T0 = [0, 0.58, -0.42]; p.push(seg(T0, [0, 0.66, -0.6], 0.05, 0.05, fur, L(6, T0, FUR)), E(0, 0.72, -0.72, 0.07, 0.07, 0.13, fur, L(6, T0, FUR)), E(0, 0.78, -0.84, 0.05, 0.05, 0.08, dark, L(6, T0, FUR)));
    [[1, -1, 0.24], [2, 1, 0.24], [3, -1, -0.26], [4, 1, -0.26]].forEach(([limb, s, z]) => { const hip = [s * 0.12, 0.5, z];
      p.push(E(s * 0.12, 0.44, z, 0.07, 0.11, 0.08, fur, L(limb, hip, FUR)), seg([s * 0.13, 0.36, z], [s * 0.13, 0.05, z + 0.03], 0.04, 0.03, dark, L(limb, hip, FUR)),
        E(s * 0.13, 0.035, z + 0.06, 0.045, 0.03, 0.065, dark, L(limb, hip, FUR)));
      for (let c = -1; c <= 1; c++) p.push(CONE(s * 0.13 + c * 0.02, 0.02, z + 0.12, 0.008, 0.04, 0xF0E8D8, Math.PI / 2, 0, 0, L(limb, hip))); });
    return p; },
  bulwark() { const shell = 0x6A4B32, sc = 0x8C6A42, skin = 0x7A7050, bone = 0xE0D2B0;
    const hemi = DET ? new THREE.SphereGeometry(1, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2) : new THREE.SphereGeometry(1, 10, 5, 0, Math.PI * 2, 0, Math.PI / 2);
    const p = [{ g: hemi, m: T(0, 0.2, 0, 0, 0, 0, 0.5, 0.42, 0.6), c: shell, r: 0.45, mt: 0.1 }, TOR(0, 0.21, 0, 0.5, 0.05, 0x4A3222, { rx: Math.PI / 2, sy: 1.18, r: 0.45 }),
      E(0, 0.17, 0, 0.46, 0.06, 0.56, 0xB8A070, SKIN)];
    const scutes = [[0, 0.62, 0], [0.22, 0.52, 0.18], [-0.22, 0.52, 0.18], [0.22, 0.52, -0.2], [-0.22, 0.52, -0.2], [0, 0.52, 0.34], [0, 0.52, -0.38], [0.36, 0.38, 0], [-0.36, 0.38, 0]];
    scutes.forEach(([x, y, z], k) => { if (!DET && k) return; const n = new THREE.Vector3(x, (y - 0.2) * 1.3, z).normalize(); const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), n);
      p.push({ g: new THREE.CylinderGeometry(0.12, 0.15, 0.05, 6), m: new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), q, new THREE.Vector3(1, 1, 1)), c: sc, r: 0.4 });
      if (k < 5) p.push({ g: new THREE.ConeGeometry(0.035, 0.12, 6), m: new THREE.Matrix4().compose(new THREE.Vector3(x + n.x * 0.05, y + n.y * 0.05, z + n.z * 0.05), q, new THREE.Vector3(1, 1, 1)), c: bone, r: 0.4 }); });
    const H = [0, 0.24, 0.55];
    p.push(seg([0, 0.22, 0.5], [0, 0.26, 0.64], 0.07, 0.07, skin, L(5, H, SKIN)), E(0, 0.28, 0.7, 0.13, 0.11, 0.15, skin, L(5, H, SKIN)), CONE(0, 0.25, 0.84, 0.05, 0.08, 0x3A3020, Math.PI / 2, 0, 0, L(5, H, CHITIN)),
      CONE(0, 0.42, 0.72, 0.035, 0.14, bone, -0.4, 0, 0, L(5, H)));
    for (const s of [-1, 1]) p.push(E(s * 0.08, 0.32, 0.8, 0.028, 0.028, 0.028, 0xFFD86A, L(5, H, G(1.6))));
    [[1, -1, 0.3], [2, 1, 0.3], [3, -1, -0.3], [4, 1, -0.3]].forEach(([limb, s, z]) => { const hip = [s * 0.32, 0.22, z];
      p.push(seg(hip, [s * 0.36, 0.02, z], 0.085, 0.08, skin, L(limb, hip, SKIN)), E(s * 0.36, 0.03, z + 0.03, 0.09, 0.04, 0.1, skin, L(limb, hip, SKIN)));
      for (let c = -1; c <= 1; c++) p.push(CONE(s * 0.36 + c * 0.035, 0.02, z + 0.12, 0.012, 0.05, bone, Math.PI / 2, 0, 0, L(limb, hip))); });
    p.push(CONE(0, 0.18, -0.72, 0.05, 0.18, skin, -Math.PI / 2, 0, 0, L(6, [0, 0.18, -0.6], SKIN)));
    return p; },
  troll() { const skin = 0x5E6474, dk = 0x464C5A, moss = 0x5E8A3A, wood = 0x6A4A30, H = [0, 1.18, 0.12];
    const p = [E(0, 0.62, 0, 0.26, 0.2, 0.22, skin, SKIN), E(0, 0.93, 0.05, 0.36, 0.4, 0.3, skin, Object.assign({ rx: 0.25 }, SKIN)), E(0, 0.82, 0.18, 0.27, 0.25, 0.2, 0x767C8C, SKIN),
      BOX(0, 0.52, 0.2, 0.3, 0.22, 0.03, 0x5A4030, { rx: 0.1, r: 0.95 }), BOX(0, 0.52, -0.2, 0.3, 0.2, 0.03, 0x5A4030, { rx: -0.1, r: 0.95 }), TOR(0, 0.66, 0, 0.25, 0.025, 0x4A3222, { rx: Math.PI / 2, r: 0.9 }),
      E(0, 1.28, 0.22, 0.15, 0.14, 0.16, skin, L(5, H, SKIN)), E(0, 1.34, 0.3, 0.14, 0.04, 0.08, dk, L(5, H, SKIN)), E(0, 1.2, 0.32, 0.12, 0.07, 0.1, dk, L(5, H, SKIN)), E(0, 1.27, 0.37, 0.035, 0.04, 0.04, dk, L(5, H, SKIN))];
    for (const s of [-1, 1]) { p.push(CONE(s * 0.07, 1.26, 0.38, 0.028, 0.11, 0xF0E8D0, 0.35, 0, s * 0.15, L(5, H)), E(s * 0.06, 1.31, 0.34, 0.025, 0.02, 0.02, 0xFFB03A, L(5, H, G(1.8))),
        CONE(s * 0.16, 1.3, 0.2, 0.035, 0.14, skin, 0, 0, s * 1.4, L(5, H, SKIN)), E(s * 0.3, 1.15, -0.02, 0.17, 0.12, 0.17, moss, FUR)); }
    for (let k = 0; k < 4; k++) p.push(CONE((k - 1.5) * 0.04, 1.43, 0.16 - k * 0.03, 0.03, 0.12, 0x2E3A22, -0.4 - k * 0.2, 0, 0, L(5, H, FUR)));
    p.push(E(0, 1.05, -0.22, 0.26, 0.2, 0.12, moss, FUR), E(0.12, 0.9, -0.28, 0.07, 0.06, 0.06, 0x8A8E98, SKIN), E(-0.1, 1.12, -0.3, 0.06, 0.05, 0.05, 0x8A8E98, SKIN));
    for (const [limb, s] of [[1, -1], [2, 1]]) { const hip = [s * 0.16, 0.6, 0]; p.push(seg(hip, [s * 0.18, 0.3, 0.04], 0.12, 0.1, skin, L(limb, hip, SKIN)), E(s * 0.18, 0.3, 0.05, 0.08, 0.08, 0.08, dk, L(limb, hip, SKIN)),
      seg([s * 0.18, 0.3, 0.04], [s * 0.19, 0.04, 0], 0.09, 0.08, skin, L(limb, hip, SKIN)), E(s * 0.19, 0.04, 0.08, 0.1, 0.05, 0.14, dk, L(limb, hip, SKIN))); }
    for (const [limb, s] of [[7, -1], [8, 1]]) { const sh = [s * 0.4, 1.12, 0.06];
      p.push(seg(sh, [s * 0.46, 0.8, 0.1], 0.1, 0.08, skin, L(limb, sh, SKIN)), seg([s * 0.46, 0.8, 0.1], [s * 0.46, 0.5, 0.16], 0.09, 0.08, skin, L(limb, sh, SKIN)), E(s * 0.46, 0.46, 0.17, 0.11, 0.11, 0.11, dk, L(limb, sh, SKIN)));
      if (s > 0) { p.push(seg([0.46, 0.46, 0.17], [0.5, 0.35, 0.72], 0.04, 0.09, wood, L(limb, sh, { r: 0.9 })));
        for (let k = 0; k < 4; k++) p.push(CONE(0.5 + Math.cos(k * 1.6) * 0.08, 0.36 + Math.sin(k * 1.6) * 0.08, 0.6 - k * 0.04, 0.02, 0.08, 0x8A8A90, Math.sin(k * 1.6) * 1.4, 0, -Math.cos(k * 1.6) * 1.4, L(limb, sh, METAL))); } }
    return p; },
  wisp() { const p = [E(0, 0, 0, 0.13, 0.13, 0.13, 0xBFEFFF, G(0.55)), E(0, 0, 0, 0.21, 0.24, 0.21, 0x4E7EAE, G(0.06, { r: 0.2 }))];
    for (let k = 0; k < 3; k++) p.push(Object.assign(CONE((k - 1) * 0.06, -0.04, -0.24, 0.055, 0.22, 0x6E9CC8, -Math.PI / 2, 0, (k - 1) * 0.3), L(6, [0, 0, -0.12], G(0.03))));
    for (const [limb, s] of [[9, -1], [10, 1]]) { p.push(E(s * 0.3, 0.1, -0.02, 0.26, 0.018, 0.13, 0xE8F6FF, L(limb, [s * 0.1, 0.08, 0], G(0.08, { rz: s * 0.25 }))),
      E(s * 0.22, -0.02, -0.08, 0.16, 0.014, 0.08, 0xD0E8FF, L(limb, [s * 0.1, 0, -0.04], G(0.06, { rz: -s * 0.2 })))); }
    for (let k = 0; k < 3; k++) { const a = k * 2.1; p.push(E(Math.cos(a) * 0.3, 0.12, Math.sin(a) * 0.3, 0.025, 0.025, 0.025, 0xE0FFFF, L(6, [0, 0, 0], G(1.2)))); }
    for (const s of [-1, 1]) p.push(E(s * 0.07, 0.05, 0.17, 0.034, 0.045, 0.028, 0x10203A, CHITIN));
    return p; },
  knight() { const steel = 0x6A7A9E, cloth = 0x34466E, gold = 0xD8B060, H = [0, 1.0, 0], M = METAL;
    const p = [E(0, 0.62, 0, 0.15, 0.11, 0.11, cloth, SKIN), E(0, 0.83, 0, 0.19, 0.23, 0.13, cloth, SKIN), E(0, 0.87, 0.05, 0.17, 0.18, 0.1, 0x9AAACE, M),
      TOR(0, 0.66, 0, 0.14, 0.02, 0x4A3222, { rx: Math.PI / 2, r: 0.8 }), TOR(0, 1.02, 0, 0.09, 0.025, steel, Object.assign({ rx: Math.PI / 2 }, M)),
      BOX(0, 0.72, -0.12, 0.3, 0.55, 0.02, 0x7A2A26, L(6, [0, 1.0, -0.1], { rx: 0.12, r: 0.95 })),
      { g: DET ? new THREE.CylinderGeometry(0.11, 0.12, 0.18, 14) : new THREE.CylinderGeometry(0.11, 0.12, 0.18, 6), m: T(0, 1.1, 0), c: steel, limb: 5, pivot: H, r: 0.28, mt: 0.9 },
      E(0, 1.19, 0, 0.11, 0.07, 0.12, steel, L(5, H, M)), BOX(0, 1.1, 0.115, 0.15, 0.022, 0.02, 0x7FE8FF, L(5, H, G(2))), CONE(0, 1.3, -0.03, 0.045, 0.2, 0xB03A2E, -0.5, 0, 0, L(5, H, FUR))];
    for (const s of [-1, 1]) { p.push(E(s * 0.21, 0.99, 0, 0.1, 0.07, 0.1, steel, M), CONE(s * 0.24, 1.07, 0, 0.03, 0.1, gold, 0, 0, -s * 0.6, M), CONE(s * 0.13, 1.25, 0.02, 0.02, 0.14, 0xE0D2B0, 0, 0, -s * 0.7, L(5, H)),
      BOX(s * 0.08, 0.6, 0.07, 0.1, 0.14, 0.03, steel, Object.assign({ rx: -0.15, rz: s * 0.1 }, M))); }
    for (const [limb, s] of [[1, -1], [2, 1]]) { const hip = [s * 0.08, 0.56, 0];
      p.push(seg(hip, [s * 0.09, 0.3, 0.02], 0.065, 0.055, steel, L(limb, hip, M)), E(s * 0.09, 0.3, 0.04, 0.05, 0.05, 0.05, 0x9AAACE, L(limb, hip, M)),
        seg([s * 0.09, 0.3, 0.02], [s * 0.1, 0.04, 0.01], 0.055, 0.05, steel, L(limb, hip, M)), E(s * 0.1, 0.03, 0.06, 0.055, 0.035, 0.1, 0x3A4460, L(limb, hip, M))); }
    const sl = [-0.24, 0.95, 0]; p.push(seg(sl, [-0.28, 0.66, 0.1], 0.05, 0.045, steel, L(7, sl, M)),
      { g: new THREE.CylinderGeometry(0.2, 0.2, 0.04, DET ? 20 : 8), m: T(-0.31, 0.68, 0.2, Math.PI / 2, 0, 0), c: 0x7A2A26, limb: 7, pivot: sl, r: 0.6 },
      TOR(-0.31, 0.68, 0.22, 0.2, 0.018, gold, L(7, sl, M)), E(-0.31, 0.68, 0.235, 0.05, 0.05, 0.03, gold, L(7, sl, M)), BOX(-0.31, 0.68, 0.226, 0.02, 0.24, 0.01, 0xFFD890, L(7, sl, G(0.6))), BOX(-0.31, 0.72, 0.226, 0.16, 0.02, 0.01, 0xFFD890, L(7, sl, G(0.6))));
    const sr = [0.24, 0.95, 0]; p.push(seg(sr, [0.28, 0.68, 0.1], 0.05, 0.045, steel, L(8, sr, M)), BOX(0.29, 0.88, 0.32, 0.03, 0.55, 0.07, 0xDDE2EA, L(8, sr, Object.assign({ rx: 0.9 }, M))),
      BOX(0.29, 0.7, 0.14, 0.18, 0.03, 0.04, gold, L(8, sr, Object.assign({ rx: 0.9 }, M))), E(0.29, 0.64, 0.07, 0.03, 0.03, 0.03, gold, L(8, sr, M)));
    return p; },
  budling() { const bulb = 0x9A7430, H = [0, 0.62, 0];
    const p = [E(0, 0.36, 0, 0.28, 0.28, 0.28, bulb, SKIN), E(0, 0.36, 0, 0.29, 0.22, 0.29, 0xB08A40, SKIN), CONE(0, 0.72, 0, 0.14, 0.26, bulb, 0, 0, 0, SKIN),
      E(0, 0.3, 0.25, 0.06, 0.025, 0.02, 0x3A2410, SKIN)];
    for (let k = 0; k < 3; k++) p.push(TOR(0, 0.26 + k * 0.1, 0, 0.27 - Math.abs(k - 1) * 0.04, 0.012, 0x7A5820, { rx: Math.PI / 2, r: 0.8 }));
    for (let k = 0; k < 4; k++) { const a = k * 1.57 + 0.4; p.push(E(Math.cos(a) * 0.14, 0.84, Math.sin(a) * 0.14, 0.2, 0.025, 0.08, 0x6A9A3A, L(5, H, { ry: -a, rz: 0.5, r: 0.6 }))); }
    for (let k = 0; k < 5; k++) { const a = k * 1.256; p.push(E(Math.cos(a) * 0.06, 0.95, Math.sin(a) * 0.06, 0.07, 0.02, 0.045, 0xE89AC0, L(5, H, { ry: -a, rz: -0.6, r: 0.5 }))); }
    p.push(E(0, 0.96, 0, 0.035, 0.035, 0.035, 0xFFE070, L(5, H, G(1.8))));
    for (const s of [-1, 1]) p.push(E(s * 0.1, 0.42, 0.24, 0.045, 0.06, 0.03, 0xFFE08A, G(1.5)));
    [[1, -1, 0.12], [2, 1, 0.12], [3, -1, -0.12], [4, 1, -0.12]].forEach(([limb, s, z]) => { const hip = [s * 0.14, 0.18, z];
      p.push(seg(hip, [s * 0.2, 0.08, z * 1.3], 0.05, 0.035, 0x6A4A2A, L(limb, hip, FUR)), seg([s * 0.2, 0.08, z * 1.3], [s * 0.24, 0, z * 1.6], 0.035, 0.012, 0x5A3A1A, L(limb, hip, FUR))); });
    return p; },
  boss() { const stone = 0x2E2A34, st2 = 0x3C3744, cr = 0xB06AF0, rune = 0xFF8A3A, H = [0, 1.85, 0.1];
    const b = (x, y, z, sx, sy, sz, c, ex = {}) => Object.assign({ g: R.blob(DET ? 1 : 0, 0.35, (x * 13 + y * 7 + z * 3) | 0 + 50, true), m: T(x, y, z, ex.rx || 0, ex.ry || 0, 0, sx, sy, sz), c, r: 0.85 }, ex);
    const p = [b(0, 0.95, 0, 0.36, 0.25, 0.28, stone), b(0, 1.4, 0.02, 0.62, 0.5, 0.44, st2), b(0, 1.3, 0.3, 0.4, 0.34, 0.2, stone),
      { g: new THREE.OctahedronGeometry(0.16, 0), m: T(0, 1.42, 0.5, 0, 0, 0, 1, 1.4, 1), c: 0xFF7A3A, glow: 2.6, r: 0.2 },
      b(0, 1.95, 0.16, 0.24, 0.2, 0.22, stone, L(5, H)), b(0, 1.86, 0.3, 0.16, 0.08, 0.1, st2, L(5, H))];
    for (let k = 0; k < 5; k++) p.push(BOX((k - 2) * 0.1, 1.2 + (k % 2) * 0.12, 0.44, 0.02, 0.18, 0.02, rune, G(1.8, { rz: (k - 2) * 0.3 })));
    for (const s of [-1, 1]) { p.push(E(s * 0.09, 1.97, 0.36, 0.045, 0.03, 0.03, 0xFF9A4A, L(5, H, G(2.4))), CONE(s * 0.2, 2.15, 0.1, 0.05, 0.3, 0x2E2A34, -0.3, 0, -s * 0.7, L(5, H)));
      p.push(b(s * 0.62, 1.74, 0, 0.3, 0.24, 0.3, st2)); for (let k = 0; k < 3; k++) p.push(CONE(s * (0.5 + k * 0.12), 1.95 + k * 0.05, -0.15 + k * 0.08, 0.06, 0.34, cr, -0.3, 0, -s * 0.5, G(1.5, { r: 0.15 }))); }
    for (let k = 0; k < 4; k++) p.push(CONE((k - 1.5) * 0.18, 1.8, -0.35, 0.07, 0.42, cr, -0.6, 0, 0, G(1.5, { r: 0.15 })));
    for (const [limb, s] of [[1, -1], [2, 1]]) { const hip = [s * 0.3, 0.9, 0]; p.push(seg(hip, [s * 0.33, 0.45, 0.05], 0.17, 0.15, stone, L(limb, hip)), b(s * 0.33, 0.5, 0.1, 0.16, 0.14, 0.14, st2, L(limb, hip)), b(s * 0.34, 0.2, 0.08, 0.2, 0.2, 0.26, st2, L(limb, hip))); }
    for (const [limb, s] of [[7, -1], [8, 1]]) { const sh = [s * 0.72, 1.7, 0.02]; p.push(seg(sh, [s * 0.82, 1.15, 0.12], 0.18, 0.14, stone, L(limb, sh)), b(s * 0.85, 0.82, 0.18, 0.3, 0.3, 0.3, st2, L(limb, sh)),
      BOX(s * 0.8, 1.35, 0.2, 0.02, 0.26, 0.02, rune, L(limb, sh, G(1.6))));
      for (let k = 0; k < 3; k++) p.push(Object.assign({ g: new THREE.OctahedronGeometry(0.06, 0), m: T(s * 0.85 + (k - 1) * 0.1, 0.92, 0.46), c: cr, glow: 2, limb, pivot: sh })); }
    return p; },
};
// per-type presentation: model scale, gait (radians per world unit), hover height
const TYPE = { grub: [0.76, 7, 0], skitter: [0.82, 20, 0], dasher: [0.76, 9.5, 0], bulwark: [0.8, 9.5, 0], troll: [0.94, 5.2, 0], wisp: [1.05, 7, 1.15], knight: [0.88, 6.4, 0], budling: [0.86, 12, 0], boss: [1.55, 2.2, 0] };

const VERT_PARS = `attribute float aLimb; attribute vec3 aPivot; attribute float aGlow; attribute vec4 aAnim; attribute vec2 aMat; varying float vGlow; varying vec3 vBase; varying vec2 vMat; varying float vDie; varying vec3 vObj;
  mat3 rX(float a){ float c=cos(a), s=sin(a); return mat3(1.,0.,0., 0.,c,s, 0.,-s,c); }
  mat3 rY(float a){ float c=cos(a), s=sin(a); return mat3(c,0.,-s, 0.,1.,0., s,0.,c); }
  mat3 rZ(float a){ float c=cos(a), s=sin(a); return mat3(c,s,0., -s,c,0., 0.,0.,1.); }
  mat3 limbRot(){ float t = aAnim.x, mv = aAnim.y, l = floor(aLimb + 0.5);
    if (l == 1. || l == 4.) return rX(sin(t) * 0.75 * mv);
    if (l == 2. || l == 3.) return rX(-sin(t) * 0.75 * mv);
    if (l == 5.) return rX(sin(t * 2.) * 0.07 * mv + 0.05 * sin(uTime * 1.3 + t)) * rY(sin(uTime * 0.7 + t * 0.3) * 0.12);
    if (l == 6.) return rY(sin(t * 0.9 + uTime) * 0.35);
    if (l == 7.) return rX(-sin(t) * 0.55 * mv);
    if (l == 8.) return rX(sin(t) * 0.55 * mv);
    if (l == 9.) return rZ(-sin(t * 1.4) * 0.75);
    if (l == 10.) return rZ(sin(t * 1.4) * 0.75);
    if (l >= 11. && l <= 14.) return rY(sin(t - (l - 11.) * 1.1) * 0.14 * mv);
    if (l == 15.) return rY(sin(t) * 0.45 * mv);
    if (l == 16.) return rY(-sin(t) * 0.45 * mv);
    return mat3(1.); }
  vec3 limbOff(){ float t = aAnim.x, mv = aAnim.y, l = floor(aLimb + 0.5); vec3 o = vec3(0., abs(sin(t)) * 0.035 * mv, 0.);
    if (l >= 11. && l <= 14.) o.y += max(0., sin(t - (l - 11.) * 1.1)) * 0.06 * mv;
    if (l == 15.) o.y += max(0., cos(t)) * 0.04 * mv; if (l == 16.) o.y += max(0., -cos(t)) * 0.04 * mv;
    return o; }`;
function animate(mat, isDepth) {
  mat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = R.clock;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;\n' + VERT_PARS);
    if (!isDepth) sh.vertexShader = sh.vertexShader.replace('#include <beginnormal_vertex>', '#include <beginnormal_vertex>\nobjectNormal = limbRot() * objectNormal;');
    sh.vertexShader = sh.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      transformed = aPivot + limbRot() * (transformed - aPivot) + limbOff();
      float breathe = 1. + sin(uTime * 2.3 + aAnim.x * 0.21) * 0.018;                   // idle breathing
      transformed.y *= breathe; transformed.xz *= 2. - breathe;
      float hit = aAnim.w; transformed.y *= 1. - hit * 0.16; transformed.xz *= 1. + hit * 0.1; // flinch on hit
      float dieT = aAnim.z; transformed.y -= dieT * dieT * 0.12; vDie = dieT; vObj = position;
      vGlow = aGlow * (1. - dieT); vMat = aMat;
      #ifdef USE_COLOR
      vBase = color.rgb;
      #else
      vBase = vec3(1.);
      #endif`);
    if (!isDepth) sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nvarying float vGlow; varying vec3 vBase; varying vec2 vMat; varying float vDie; varying vec3 vObj;\nfloat dHash(vec3 p){ p = fract(p * 0.3183099 + 0.1); p *= 17.0; return fract(p.x * p.y * p.z * (p.x + p.y + p.z)); }\nfloat dNoise(vec3 p){ vec3 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f); return mix(mix(mix(dHash(i), dHash(i + vec3(1,0,0)), f.x), mix(dHash(i + vec3(0,1,0)), dHash(i + vec3(1,1,0)), f.x), f.y), mix(mix(dHash(i + vec3(0,0,1)), dHash(i + vec3(1,0,1)), f.x), mix(dHash(i + vec3(0,1,1)), dHash(i + vec3(1,1,1)), f.x), f.y), f.z); }')
      .replace('#include <clipping_planes_fragment>', '#include <clipping_planes_fragment>\nfloat dn = dNoise(vObj * 9.) * 0.7 + dNoise(vObj * 23.) * 0.3; if (vDie > 0.001 && dn < vDie * 1.1) discard;')
      .replace('#include <roughnessmap_fragment>', 'float roughnessFactor = vMat.x;')
      .replace('#include <metalnessmap_fragment>', 'float metalnessFactor = vMat.y;')
      .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
        diffuseColor.rgb *= mix(0.5, 1.0, smoothstep(-0.02, 0.5, vObj.y)) * (1.0 + 0.12 * smoothstep(0.25, 0.9, vObj.y)); // grounded: darker feet, lit back
        totalEmissiveRadiance += vGlow * vBase * 2.8;                                        // glow ignores hit-flash / status tint
        if (vDie > 0.001) totalEmissiveRadiance += vec3(3.2, 1.2, 4.0) * (1. - smoothstep(0.0, 0.09, dn - vDie * 1.1)); // dissolving edge
        float rimF = pow(1. - clamp(dot(normal, normalize(vViewPosition)), 0., 1.), 3.);
        totalEmissiveRadiance += (diffuseColor.rgb * 0.8 + 0.1) * rimF * 0.55;                // stylised rim light`);
  };
  mat.customProgramCacheKey = () => 'creature2' + (isDepth ? 'D' : 'C');
  return mat;
}

R.buildCreatures = function (world, sim, Q, CAP, MT_KEYS) {
  const lin = R.lin, meshes = {}, animAttr = {}, lod = {}, lodAttr = {};
  const mat = animate(new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 }));
  const depthMat = animate(new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking }), true);
  let shadowsOn = Q !== 'low';
  const mk = (k, detail, cap) => { DET = detail; const geo = R.merge(MODELS[k]()); DET = 1;
    const aa = new THREE.InstancedBufferAttribute(new Float32Array(cap * 4), 4); aa.setUsage(THREE.DynamicDrawUsage); geo.setAttribute('aAnim', aa);
    const im = new THREE.InstancedMesh(geo, mat, cap); im.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3).fill(1), 3);
    im.instanceMatrix.setUsage(THREE.DynamicDrawUsage); im.count = 0; im.frustumCulled = false; im.castShadow = shadowsOn && detail === 1; im.customDepthMaterial = depthMat;
    world.add(im); return [im, aa]; };
  for (const k of MT_KEYS) { const cap = k === 'boss' ? 4 : Math.min(CAP, 3000) + 400;
    [meshes[k], animAttr[k]] = mk(k, 1, k === 'boss' ? 4 : 420); [lod[k], lodAttr[k]] = mk(k, 0, cap); }
  const inst = (geo, material, cap, color = true) => { const im = new THREE.InstancedMesh(geo, material, cap);
    if (color) im.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3).fill(1), 3);
    im.instanceMatrix.setUsage(THREE.DynamicDrawUsage); im.count = 0; im.frustumCulled = false; world.add(im); return im; };
  const blob = inst(new THREE.CircleGeometry(0.5, 16), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3, depthWrite: false }), CAP, false);
  const shield = inst(new THREE.SphereGeometry(1, 20, 14), new THREE.MeshStandardMaterial({ color: lin(0x9FD8FF), emissive: lin(0x3A7AB0), emissiveIntensity: 0.22, transparent: true, opacity: 0.12, depthWrite: false, roughness: 0.1 }), 1024, false);
  R.rim(shield.material, 0.9);
  const elite = inst(new THREE.TorusGeometry(0.5, 0.05, 6, 28), new THREE.MeshBasicMaterial({ color: 0xffffff }), 256);
  const barBg = inst(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ color: lin(0x1a1210), depthTest: false, transparent: true, opacity: 0.85 }), CAP, false);
  const barFg = inst(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ color: 0xffffff, depthTest: false }), CAP);
  barBg.renderOrder = 10; barFg.renderOrder = 11;

  const yaw = new Float32Array(CAP), gen = new Uint32Array(CAP), phase = new Float32Array(CAP);
  const fr = new THREE.Frustum(), pm = new THREE.Matrix4(), bs = new THREE.Sphere(); const stats = { culled: 0, hi: 0 };
  const dying = [];
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), v = new THREE.Vector3(), sc = new THREE.Vector3(), c = new THREE.Color(), tv = new THREE.Vector3();
  const C = { hp1: lin(0x8BD65A), hp2: lin(0xF2C94C), hp3: lin(0xE0604A), sh: lin(0x9FD8FF) };
  const EL = ['ember', 'tide', 'grove', 'void', 'storm', 'iron'], ELC = {}; for (const [k, h] of Object.entries({ ember: 0xEE6A34, tide: 0x3FA0E8, grove: 0x7CC24A, void: 0xA56BF0, storm: 0xF4DA4A, iron: 0xA9ADB3 })) ELC[k] = lin(h).multiplyScalar(1.6);
  const ringC = { boss: lin(0xFF5A3C).multiplyScalar(2), frenzy: lin(0xFFB347).multiplyScalar(1.5) };
  function onDeath(ev, idx) { dying.push({ type: ev.type, x: ev.x, z: ev.z, yaw: idx >= 0 ? yaw[idx] : 0, s: ev.elite ? 1.3 : 1, t: 0 }); if (dying.length > 400) dying.shift(); }

  function draw(alpha, time, dt, camera, lowDetail) {
    const m = sim.m, counts = {}, lcounts = {}; for (const k of MT_KEYS) counts[k] = lcounts[k] = 0;
    const fx = camera.userData.focusX || 11, fz = camera.userData.focusZ || 7, cd = camera.userData.dist || 25, near2 = cd < 20 ? Math.pow(cd * 1.25, 2) : 0; let hiN = 0;
    let nb = 0, ns = 0, ne = 0, nbar = 0; const camQ = camera.quaternion, MT = AH.MT;
    camera.updateMatrixWorld(); fr.setFromProjectionMatrix(pm.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse)); let culled = 0;
    for (let i = 0; i < CAP; i++) {
      if (!m.alive[i]) continue;
      const key = MT_KEYS[m.type[i]], [ms, gait, hover] = TYPE[key], d = MT[key];
      const x = m.px[i] + (m.x[i] - m.px[i]) * alpha, z = m.pz[i] + (m.z[i] - m.pz[i]) * alpha;
      const fly = m.flags[i] & AH.F_FLY, boss = m.flags[i] & AH.F_BOSS, el = m.flags[i] & AH.F_ELITE;
      if (gen[i] !== m.gen[i]) { gen[i] = m.gen[i]; yaw[i] = Math.atan2(m.dirx[i], m.dirz[i]); phase[i] = (i * 2.399) % 6.283; }
      const ty = Math.atan2(m.dirx[i], m.dirz[i]); let dy = ty - yaw[i]; dy = ((dy + Math.PI * 3) % (Math.PI * 2)) - Math.PI; yaw[i] += dy * Math.min(1, dt * 10);
      const s = ms * (el ? 1.3 : 1);
      const spd = m.speed[i] * m.enrage[i] * (m.slowT[i] > 0 ? 0.55 : 1) * (m.frenzyBoost[i] ? 1.25 : 1);
      phase[i] += dt * spd * gait;
      const gy = fly ? 0 : R.groundY(x, z), y = gy + (fly ? hover + Math.sin(time * 2 + i) * 0.06 : 0);
      bs.center.set(x, y + 0.5 * s, z); bs.radius = 1.6 * s + 0.5; if (!fr.intersectsSphere(bs)) { culled++; continue; } // off-screen: not drawn at all
      e.set(0, yaw[i], 0); q.setFromEuler(e); m4.compose(v.set(x, y, z), q, sc.set(s, s, s));
      const d2 = (x - fx) * (x - fx) + (z - fz) * (z - fz);
      const hi = boss || (hiN < 300 && d2 < near2 && counts[key] < meshes[key].instanceMatrix.count); if (hi) hiN++;
      const tim = hi ? meshes[key] : lod[key], tat = hi ? animAttr[key] : lodAttr[key];
      const n = hi ? counts[key]++ : lcounts[key]++; tim.setMatrixAt(n, m4);
      tat.setXYZW(n, phase[i], lowDetail && !boss ? 0 : 1, 0, m.hitT[i] > 0 ? m.hitT[i] / 0.12 : 0);
      c.setRGB(1, 1, 1);
      // status tints stay in range: pale creatures must not bloom out to white
      if (m.slowT[i] > 0) c.setRGB(0.55, 0.78, 1.2);
      if (m.burnT[i] > 0) { const f = 0.85 + 0.15 * Math.sin(time * 20 + i); c.setRGB(1.25 * f, 0.72, 0.45); }
      if (m.hitT[i] > 0) c.multiplyScalar(1.18);
      tim.setColorAt(n, c);
      const r = d.size * (el ? 1.3 : 1) * 1.9;
      if (!shadowsOn || fly || !hi) { m4.makeRotationX(-Math.PI / 2).scale(sc.set(r * (fly ? 0.7 : 1), r * (fly ? 0.7 : 1), 1)).setPosition(x, (fly ? R.groundY(x, z) : gy) + 0.02, z); blob.setMatrixAt(nb++, m4); }
      const top = y + (key === 'boss' ? 2.35 : key === 'troll' ? 1.45 : key === 'knight' ? 1.35 : key === 'wisp' ? 0.35 : key === 'dasher' ? 0.95 : 0.8) * s;
      if (m.shield[i] > 0 && ns < 1024) { const rr = r * 0.62 + 0.1; m4.makeScale(rr, rr, rr).setPosition(x, y + (fly ? 0 : rr * 0.7), z); shield.setMatrixAt(ns++, m4); }
      if ((el || boss) && ne < 256) { e.set(Math.PI / 2, 0, time * 1.5); q.setFromEuler(e); m4.compose(v.set(x, top + 0.12, z), q, sc.set(r * 0.5, r * 0.5, r * 0.5)); elite.setMatrixAt(ne, m4);
        elite.setColorAt(ne, m.immune[i] >= 0 ? ELC[EL[m.immune[i]]] : boss ? ringC.boss : ringC.frenzy); ne++; }
      const hpF = m.hp[i] / m.maxHp[i];
      if (hpF < 0.999 || boss || el || m.shield[i] > 0) {
        const bw = boss ? 2.2 : Math.max(0.5, r * 0.9), by = top + 0.3;
        m4.compose(v.set(x, by, z), camQ, sc.set(bw + 0.06, boss ? 0.2 : 0.11, 1)); barBg.setMatrixAt(nbar, m4);
        v.set(-bw / 2 + bw * hpF / 2, 0, 0.001).applyQuaternion(camQ);
        m4.compose(v.add(tv.set(x, by, z)), camQ, sc.set(Math.max(0.001, bw * hpF), boss ? 0.14 : 0.07, 1)); barFg.setMatrixAt(nbar, m4);
        barFg.setColorAt(nbar, m.shield[i] > 0 ? C.sh : hpF > 0.5 ? C.hp1 : hpF > 0.25 ? C.hp2 : C.hp3); nbar++;
      }
    }
    for (let k = 0; k < dying.length; k++) { const D = dying[k]; D.t += dt; const f = D.t / 0.7; if (f >= 1) { dying.splice(k--, 1); continue; }
      const im = lod[D.type]; if (!im) continue; const n = lcounts[D.type]; if (n >= im.instanceMatrix.count) continue; lcounts[D.type]++;
      const [ms, , hover] = TYPE[D.type], s = ms * D.s; const y = (hover ? hover * (1 - f) : 0) + R.groundY(D.x, D.z);
      e.set(0, D.yaw, 0); q.setFromEuler(e); m4.compose(v.set(D.x, y, D.z), q, sc.set(s, s, s)); im.setMatrixAt(n, m4); lodAttr[D.type].setXYZW(n, 0, 0, f, 0);
      im.setColorAt(n, c.setRGB(0.7, 0.62, 0.66)); }
    for (const k of MT_KEYS) for (const [im, aa, cnt] of [[meshes[k], animAttr[k], counts[k]], [lod[k], lodAttr[k], lcounts[k]]]) { im.count = cnt; im.instanceMatrix.needsUpdate = true; im.instanceColor.needsUpdate = true; aa.needsUpdate = true; }
    stats.culled = culled; stats.hi = hiN;
    blob.count = nb; blob.instanceMatrix.needsUpdate = true; shield.count = ns; shield.instanceMatrix.needsUpdate = true;
    elite.count = ne; elite.instanceMatrix.needsUpdate = true; elite.instanceColor.needsUpdate = true;
    barBg.count = barFg.count = nbar; barBg.instanceMatrix.needsUpdate = barFg.instanceMatrix.needsUpdate = true; barFg.instanceColor.needsUpdate = true;
  }
  function reset() { dying.length = 0; gen.fill(0); }
  function age(dt) { for (let k = 0; k < dying.length; k++) { dying[k].t += dt; if (dying[k].t >= 0.7) dying.splice(k--, 1); } } // advance corpses without drawing (harness bulk steps)
  const tris = {}; for (const k of MT_KEYS) tris[k] = [meshes[k].geometry.attributes.position.count / 3, lod[k].geometry.attributes.position.count / 3];
  function setShadows(on) { shadowsOn = on; for (const k of MT_KEYS) meshes[k].castShadow = on; }
  return { draw, onDeath, reset, age, setShadows, meshes, tris, TYPE, stats };
};
})();
