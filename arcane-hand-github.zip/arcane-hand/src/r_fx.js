/* Arcane Hand — effects. Two instanced billboard systems (additive glow, alpha dust): one draw call each.
   Colours are linear HDR so bloom picks up magic. Every emitter here is cosmetic and is cut first under load. */
(function () {
'use strict';
const R = globalThis.AHR, lin = R.lin;
class Particles {
  constructor(world, tex, cap, additive) {
    this.cap = cap; this.n = 0; this.p = [];
    const g = new THREE.InstancedBufferGeometry(); const q = new THREE.PlaneGeometry(1, 1);
    g.index = q.index; g.setAttribute('position', q.attributes.position); g.setAttribute('uv', q.attributes.uv);
    this.pos = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3), 3); this.col = new THREE.InstancedBufferAttribute(new Float32Array(cap * 4), 4);
    this.sz = new THREE.InstancedBufferAttribute(new Float32Array(cap * 2), 2);
    for (const a of [this.pos, this.col, this.sz]) a.setUsage(THREE.DynamicDrawUsage);
    g.setAttribute('iPos', this.pos); g.setAttribute('iCol', this.col); g.setAttribute('iSz', this.sz); g.instanceCount = 0;
    this.mat = new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: { map: { value: tex } },
      vertexShader: `attribute vec3 iPos; attribute vec4 iCol; attribute vec2 iSz; varying vec4 vC; varying vec2 vUv;
        void main(){ vC = iCol; vUv = uv; vec4 mv = modelViewMatrix * vec4(iPos, 1.); float c = cos(iSz.y), s = sin(iSz.y);
          vec2 p = vec2(position.x * c - position.y * s, position.x * s + position.y * c) * iSz.x; mv.xy += p; gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform sampler2D map; varying vec4 vC; varying vec2 vUv; void main(){ float a = texture2D(map, vUv).a * vC.a; if (a < 0.003) discard;
        gl_FragColor = vec4(vC.rgb * ${additive ? 'a' : '1.'}, ${additive ? '1.' : 'a'});\n#include <tonemapping_fragment>\n#include <encodings_fragment>\n}` });
    this.mesh = new THREE.Mesh(g, this.mat); this.mesh.frustumCulled = false; this.mesh.renderOrder = additive ? 6 : 5; world.add(this.mesh); this.g = g;
  }
  // x,y,z, vx,vy,vz, life, size0, size1, color(THREE.Color, HDR), a0, a1, grav, drag
  add(x, y, z, vx, vy, vz, life, s0, s1, c, a0 = 1, a1 = 0, grav = 0, drag = 0) {
    if (this.p.length >= this.cap) return; this.p.push({ x, y, z, vx, vy, vz, t: 0, life, s0, s1, r: c.r, g: c.g, b: c.b, a0, a1, grav, drag, rot: Math.random() * 6.28, vr: (Math.random() - 0.5) * 3 });
  }
  update(dt) {
    const P = this.p, pos = this.pos.array, col = this.col.array, sz = this.sz.array; let n = 0;
    for (let k = 0; k < P.length; k++) { const p = P[k]; p.t += dt; if (p.t >= p.life) { P[k] = P[P.length - 1]; P.pop(); k--; continue; }
      const f = p.t / p.life; p.vy -= p.grav * dt; const d = 1 - p.drag * dt; p.vx *= d; p.vy *= d; p.vz *= d; p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.rot += p.vr * dt;
      pos[n * 3] = p.x; pos[n * 3 + 1] = p.y; pos[n * 3 + 2] = p.z; const a = p.a0 + (p.a1 - p.a0) * f;
      col[n * 4] = p.r; col[n * 4 + 1] = p.g; col[n * 4 + 2] = p.b; col[n * 4 + 3] = a; sz[n * 2] = p.s0 + (p.s1 - p.s0) * f; sz[n * 2 + 1] = p.rot; n++; }
    this.g.instanceCount = n; this.pos.needsUpdate = this.col.needsUpdate = this.sz.needsUpdate = true; this.n = n;
  }
  clear() { this.p.length = 0; }
}

R.buildFX = function (world, tex) {
  const glow = new Particles(world, tex.soft, 6000, true), dust = new Particles(world, tex.soft, 2500, false);
  const E = { ember: [lin(0xFF7A2A), lin(0xFFD060)], tide: [lin(0x4FB8F0), lin(0xC8F4FF)], grove: [lin(0x8CD04A), lin(0xE8FF9A)], void: [lin(0x9A4AF0), lin(0xE0B8FF)], storm: [lin(0xFFE070), lin(0xFFFFFF)], iron: [lin(0xFFB060), lin(0xFFF0D0)] };
  const hdr = (c, k) => c.clone().multiplyScalar(k);
  const rnd = Math.random, proj = [];
  let cut = 0;
  const fx = {
    glow, dust,
    setCut(c) { cut = c; },
    shot(e, top, toY) { // visual projectile; damage already resolved in the simulation
      const [c1, c2] = E[e.el], d = Math.hypot(e.tx - e.x, e.tz - e.z);
      if (e.el === 'storm') { bolt(e.x, top, e.z, e.tx, toY, e.tz, c1, e.crit ? 1.6 : 1); flash(e.tx, toY, e.tz, c2, 0.5); return; }
      const sp = e.arch === 'sniper' ? 15 : e.arch === 'heavy' ? 6.5 : 10;
      proj.push({ x0: e.x, y0: top, z0: e.z, x1: e.tx, y1: toY, z1: e.tz, t: 0, dur: Math.max(0.07, d / sp), el: e.el, arch: e.arch, crit: e.crit, lob: e.arch === 'heavy', px: e.x, py: top, pz: e.z });
    },
    muzzle(x, y, z, el) { const [c1, c2] = E[el]; flash(x, y, z, c2, 0.32); if (cut >= 2) return;
      for (let k = 0; k < 4; k++) { const a = rnd() * 6.28; glow.add(x, y, z, Math.cos(a) * 0.8, 0.6 + rnd(), Math.sin(a) * 0.8, 0.25, 0.07, 0.01, hdr(c1, 2.5), 1, 0, 2, 2); } },
    splash(x, z, el) { const [c1, c2] = E[el]; for (let k = 0; k < (cut ? 8 : 18); k++) { const a = rnd() * 6.28, s = 1.5 + rnd() * 2; glow.add(x, 0.3, z, Math.cos(a) * s, 0.5 + rnd(), Math.sin(a) * s, 0.35, 0.22, 0.05, hdr(c1, 2.5), 1, 0, 3, 3); }
      flash(x, 0.3, z, c2, 0.9); },
    chain(pts, el) { const [c1] = E[el]; for (let k = 0; k < pts.length - 1; k++) bolt(pts[k][0], 0.6, pts[k][1], pts[k + 1][0], 0.6, pts[k + 1][1], c1, 0.8); },
    pierce(x, z, ex, ez, el) { const [c1, c2] = E[el]; const n = 14; for (let k = 0; k <= n; k++) { const f = k / n; glow.add(x + (ex - x) * f, 0.6, z + (ez - z) * f, 0, 0, 0, 0.18, 0.2, 0.05, hdr(c2, 2), 1, 0); } },
    death(x, y, z, big, col) { const n = big ? 26 : cut >= 2 ? 3 : 7;
      for (let k = 0; k < n; k++) { const a = rnd() * 6.28, s = (0.4 + rnd() * 0.8) * (big ? 2 : 1); dust.add(x + Math.cos(a) * 0.1, y + 0.15, z + Math.sin(a) * 0.1, Math.cos(a) * s, 0.4 + rnd() * 0.6, Math.sin(a) * s, 0.6 + rnd() * 0.4, 0.22 * (big ? 2 : 1), 0.6 * (big ? 2.2 : 1), col, 0.55, 0, -0.2, 2.5); }
      if (cut < 2) for (let k = 0; k < (big ? 20 : 3); k++) glow.add(x, y + 0.3, z, (rnd() - 0.5) * 0.6, 1 + rnd() * 1.2, (rnd() - 0.5) * 0.6, 0.8, 0.09, 0.02, hdr(lin(0xB88AF0), 2.2), 1, 0, -0.5, 1); },
    merge(x, z, col, big) { for (let k = 0; k < (big ? 80 : 40); k++) { const a = k / 40 * 6.28 * 3, r = 0.5 + rnd() * 0.2; glow.add(x + Math.cos(a) * r, 0.1 + k * 0.03, z + Math.sin(a) * r, -Math.sin(a) * 1.5, 1.8 + rnd(), Math.cos(a) * 1.5, 0.9, 0.14, 0.03, hdr(col, 3), 1, 0, 0, 1.5); } },
    sacrifice(x0, z0, x1, z1) { const n = 24; for (let k = 0; k <= n; k++) { const f = k / n; glow.add(x0 + (x1 - x0) * f, 0.4 + Math.sin(f * Math.PI) * 1.2, z0 + (z1 - z0) * f, 0, 0.2, 0, 0.35 + f * 0.3, 0.16, 0.04, hdr(lin(0xF2C46A), 2.5), 1, 0); }
      for (let k = 0; k < 12; k++) dust.add(x0, 0.4, z0, (rnd() - 0.5) * 1.5, rnd() * 1.5, (rnd() - 0.5) * 1.5, 0.7, 0.2, 0.5, lin(0xC8C0B0), 0.6, 0, 2, 2); },
    sparkle(x, y, z, col, n = 14) { for (let k = 0; k < n; k++) { const a = rnd() * 6.28; glow.add(x + Math.cos(a) * 0.3, y + rnd() * 0.6, z + Math.sin(a) * 0.3, 0, 0.6 + rnd(), 0, 0.8, 0.1, 0.02, hdr(col, 3), 1, 0); } },
    ring(x, z, col) { for (let k = 0; k < 32; k++) { const a = k / 32 * 6.28; glow.add(x, 0.15, z, Math.cos(a) * 3, 0.2, Math.sin(a) * 3, 0.5, 0.18, 0.06, hdr(col, 2.5), 1, 0, 0, 2); } },
    // ambient: tower idle, portal, vault
    ambient(dt, towers, time) { if (cut >= 1) return;
      for (const [t, g] of towers) { const top = g.userData.top || 1;
        if (t.el === 'ember' && rnd() < dt * 14) glow.add(t.x + (rnd() - 0.5) * 0.15, top + 0.35, t.z + (rnd() - 0.5) * 0.15, (rnd() - 0.5) * 0.2, 0.9 + rnd() * 0.5, (rnd() - 0.5) * 0.2, 0.6, 0.16, 0.02, hdr(E.ember[0], 2.2), 1, 0, 0, 0.5);
        if (t.el === 'storm' && rnd() < dt * 1.5) { const a = rnd() * 6.28; bolt(t.x, top + 0.3, t.z, t.x + Math.cos(a) * 0.35, top + 0.1 + rnd() * 0.3, t.z + Math.sin(a) * 0.35, E.storm[0], 0.5); }
        if (t.el === 'void' && rnd() < dt * 4) glow.add(t.x + (rnd() - 0.5) * 0.6, top + rnd() * 0.5, t.z + (rnd() - 0.5) * 0.6, 0, 0.3, 0, 1, 0.08, 0.01, hdr(E.void[0], 2), 1, 0);
        if (t.el === 'grove' && rnd() < dt * 2) dust.add(t.x + (rnd() - 0.5) * 0.5, top + 0.2, t.z + (rnd() - 0.5) * 0.5, (rnd() - 0.5) * 0.3, -0.3, (rnd() - 0.5) * 0.3, 2, 0.06, 0.05, lin(0x9CC85A), 0.9, 0);
        if (t.tier === 4 && rnd() < dt * 8) glow.add(t.x + (rnd() - 0.5) * 0.8, top + rnd() * 0.8, t.z + (rnd() - 0.5) * 0.8, 0, 0.4, 0, 1, 0.07, 0.01, hdr(lin(0xF2C94C), 3), 1, 0);
      }
      if (rnd() < dt * 7) { const x = rnd() * 22, z = rnd() * 14; glow.add(x, 0.3 + rnd() * 1.2, z, (rnd() - 0.5) * 0.2, 0.05, (rnd() - 0.5) * 0.2, 4.5, 0.05, 0.03, hdr(lin(0xF8E8A0), 2.2), 0.9, 0); }
      if (rnd() < dt * 3) { const side = rnd() < 0.5, x = side ? rnd() * 22 : (rnd() < 0.5 ? -1.5 : 23.5), z = side ? (rnd() < 0.5 ? -1.6 : 15.6) : rnd() * 14;
        dust.add(x, 2.6, z, (rnd() - 0.5) * 0.4, -0.35, (rnd() - 0.5) * 0.4, 6, 0.07, 0.07, lin([0x8AA848, 0xC89A3A, 0xB86A2E][(rnd() * 3) | 0]), 1, 0.6); }
      const P = R.portal; if (P && rnd() < dt * 20) { const a = rnd() * 6.28; glow.add(P.position.x + Math.cos(a) * 0.05, 1.0 + Math.sin(a) * 1.0, P.position.z + Math.cos(a) * 0.9, 0.6, 0.1, 0, 0.9, 0.1, 0.01, hdr(lin(0xA060FF), 2.5), 1, 0); }
      const V = R.vault; if (V && rnd() < dt * 10) glow.add(V.position.x + (rnd() - 0.5) * 1.4, 0.4, V.position.z + (rnd() - 0.5) * 1.4, 0, 0.9, 0, 1.6, 0.08, 0.02, hdr(lin(0x7FE8DC), 2.2), 1, 0);
    },
    update(dt) {
      for (let k = 0; k < proj.length; k++) { const p = proj[k]; p.t += dt; const f = Math.min(1, p.t / p.dur); const [c1, c2] = E[p.el];
        const x = p.x0 + (p.x1 - p.x0) * f, z = p.z0 + (p.z1 - p.z0) * f, y = p.y0 + (p.y1 - p.y0) * f + (p.lob ? Math.sin(f * Math.PI) * 1.3 : 0);
        const big = p.arch === 'heavy' ? 1.6 : p.arch === 'rapid' ? 0.6 : 1;
        glow.add(x, y, z, 0, 0, 0, 0.03, 0.34 * big * (p.crit ? 1.5 : 1), 0.3 * big, hdr(c2, 2.5), 1, 1);         // hot core
        const steps = cut >= 2 ? 1 : 3;
        for (let s = 0; s < steps; s++) { const g = s / steps, tx = p.px + (x - p.px) * g, ty = p.py + (y - p.py) * g, tz = p.pz + (z - p.pz) * g;
          if (p.el === 'iron') dust.add(tx, ty, tz, 0, 0.1, 0, 0.3, 0.06 * big, 0.18 * big, lin(0x8A8680), 0.35, 0);
          else glow.add(tx, ty, tz, (Math.random() - 0.5) * 0.3, (p.el === 'ember' ? 0.5 : 0), (Math.random() - 0.5) * 0.3, p.el === 'tide' ? 0.25 : 0.35, 0.2 * big, 0.02, hdr(c1, 1.8), 0.9, 0); }
        p.px = x; p.py = y; p.pz = z;
        if (f >= 1) { impact(p.x1, p.y1, p.z1, p.el, big, p.crit); proj[k] = proj[proj.length - 1]; proj.pop(); k--; } }
      glow.update(dt); dust.update(dt);
    },
    clear() { proj.length = 0; glow.clear(); dust.clear(); },
    count() { return proj.length + glow.n + dust.n; },
  };
  function flash(x, y, z, c, s) { glow.add(x, y, z, 0, 0, 0, 0.14, s, s * 1.6, hdr(c, 2.5), 1, 0); }
  function impact(x, y, z, el, big, crit) { const [c1, c2] = E[el]; flash(x, y, z, c2, 0.45 * big * (crit ? 1.8 : 1));
    if (cut >= 2) return; for (let k = 0; k < (crit ? 10 : 4); k++) { const a = rnd() * 6.28, s = 1 + rnd() * 1.5; glow.add(x, y, z, Math.cos(a) * s, rnd() * 1.5, Math.sin(a) * s, 0.25, 0.1, 0.02, hdr(c1, 2.5), 1, 0, 4, 2); }
    if (el === 'grove') for (let k = 0; k < 3; k++) dust.add(x, y, z, (rnd() - 0.5) * 2, rnd() * 1.5, (rnd() - 0.5) * 2, 0.5, 0.07, 0.05, lin(0x6A9A3A), 1, 0, 5, 1); }
  function bolt(x0, y0, z0, x1, y1, z1, c, w) { // jagged lightning built from glow particles
    const L = Math.hypot(x1 - x0, y1 - y0, z1 - z0), n = Math.max(3, Math.floor(L / 0.25)); let px = x0, py = y0, pz = z0;
    for (let k = 1; k <= n; k++) { const f = k / n, j = k < n ? 0.14 : 0; const nx = x0 + (x1 - x0) * f + (rnd() - 0.5) * j * 2, ny = y0 + (y1 - y0) * f + (rnd() - 0.5) * j * 2, nz = z0 + (z1 - z0) * f + (rnd() - 0.5) * j * 2;
      for (let s = 0; s < 3; s++) { const g = s / 3; glow.add(px + (nx - px) * g, py + (ny - py) * g, pz + (nz - pz) * g, 0, 0, 0, 0.13, 0.12 * w, 0.06 * w, hdr(c, 3.5), 1, 0); }
      px = nx; py = ny; pz = nz; } }
  return fx;
};
})();
