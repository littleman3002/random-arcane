/* Arcane Hand — towers. Element = architecture + material language; rarity = plinth, trim, banners, floating ornaments,
   height; archetype = weapon head; ability = one physical prop. Towers are few (< 50), so each is a small group. */
(function () {
'use strict';
const R = globalThis.AHR, T = R.T, lin = R.lin;
let M = null;
function mats(tex) {
  if (M) return M;
  const std = (o) => new THREE.MeshStandardMaterial(o);
  const glow = (c, i = 2) => std({ color: lin(c), emissive: lin(c), emissiveIntensity: i, roughness: 0.4 });
  M = {
    wood: R.M.wood, brick: R.M.brick,
    stoneLight: std({ map: tex.brick, normalMap: tex.brickN, color: lin(0xF2F0EA), roughness: 0.8 }),
    stoneMid: std({ map: tex.brick, normalMap: tex.brickN, color: lin(0xC8C0B4), roughness: 0.85 }),
    basalt: std({ map: tex.brick, normalMap: tex.brickN, color: lin(0x5A4A44), roughness: 0.7, emissive: lin(0xFF6A1A), emissiveMap: tex.cracks, emissiveIntensity: 1.6 }),
    obsidian: std({ color: lin(0x1C1626), roughness: 0.18, metalness: 0.35 }),
    iron: std({ color: lin(0x3A3C40), roughness: 0.45, metalness: 0.8 }),
    brass: std({ color: lin(0xC8904A), roughness: 0.32, metalness: 1 }),
    copper: std({ color: lin(0xB8683A), roughness: 0.35, metalness: 1 }),
    silver: std({ color: lin(0xB8C0CC), roughness: 0.42, metalness: 0.85 }),
    gold: R.M.gold, bark: R.M.bark, vc: R.M.vc, leaf: R.M.leaf,
    roofBlue: std({ map: tex.shingle, normalMap: tex.shingleN, color: lin(0x5A8AC8), roughness: 0.6 }),
    roofRed: std({ map: tex.shingle, normalMap: tex.shingleN, color: lin(0xB85A3A), roughness: 0.6 }),
    water: std({ color: lin(0x6FD0F4), emissive: lin(0x2A8AC8), emissiveIntensity: 0.9, roughness: 0.05, metalness: 0.1, transparent: true, opacity: 0.88 }),
    lava: glow(0xFF6A1A, 2.6), flameA: glow(0xFF7A2A, 3.2), flameB: glow(0xFFD060, 3.6),
    voidG: glow(0xB070FF, 2.8), stormG: glow(0xFFF2A0, 3.2), groveG: glow(0xC8F060, 2.4), tideG: glow(0x7FE0FF, 2.2),
    rune: [glow(0xBDB6A4, 0.4), glow(0x7FB7D9, 1.1), glow(0x5CC9A7, 1.3), glow(0xE89A4A, 1.7), glow(0xF2C94C, 2.2)],
    cloth: [0, 0x3F6FA8, 0x2E9A7A, 0xC0662A, 0xD8A838].map(c => std({ color: lin(c || 0x888888), roughness: 0.9, side: THREE.DoubleSide })),
    trim: [null, null, null, null, null],
  };
  M.window = glow(0xFFC870, 2.2);
  // finer masonry on towers (smaller bricks read as real stonework up close)
  for (const k of ['stoneLight', 'stoneMid', 'basalt']) { const m = M[k]; m.map = m.map.clone(); m.map.repeat.set(3, 2.4); m.map.needsUpdate = true;
    m.normalMap = m.normalMap.clone(); m.normalMap.repeat.set(3, 2.4); m.normalMap.needsUpdate = true; m.normalScale = new THREE.Vector2(1.6, 1.6); }
  if (M.basalt.emissiveMap) { M.basalt.emissiveMap = M.basalt.emissiveMap.clone(); M.basalt.emissiveMap.repeat.set(2, 1.6); M.basalt.emissiveMap.needsUpdate = true; }
  M.band = {}; for (const [el, c] of Object.entries({ ember: 0xFF6A1A, tide: 0x4FC8F0, iron: 0xE8B050, grove: 0x9CE05A, void: 0xB070FF, storm: 0xFFE070 }))
    M.band[el] = std({ color: lin(0x1A1A20), metalness: 0.8, roughness: 0.35, emissive: lin(c), emissiveMap: tex.runeStrip, emissiveIntensity: 2.2 }); R.M.basaltRef = M.basalt;
  M.trim = [M.iron, std({ color: lin(0x7F9AB8), roughness: 0.6, metalness: 0.3 }), std({ color: lin(0x3F9A7E), roughness: 0.6, metalness: 0.3 }), std({ color: lin(0xB86A2E), roughness: 0.55, metalness: 0.4 }), std({ color: lin(0xC89A3A), roughness: 0.5, metalness: 0.6 })];
  // grounding: stone darkens toward the ground (contact AO), then rim light
  for (const k of ['stoneLight', 'stoneMid', 'basalt', 'obsidian', 'brick', 'wood']) { const m = M[k]; if (m.userData.ao) continue; m.userData.ao = 1;
    R.patch(m, { vars: 'varying float vWY;', begin: 'vWY = (modelMatrix * vec4(transformed, 1.)).y;', fragVars: 'varying float vWY;', fragColor: 'diffuseColor.rgb *= mix(0.42, 1.0, smoothstep(0.0, 0.75, vWY));' }); }
  for (const k of ['stoneLight', 'stoneMid', 'basalt', 'obsidian', 'iron', 'brass', 'copper', 'silver', 'roofBlue', 'roofRed', 'water']) R.rim(M[k], 0.28);
  for (const cm of M.cloth) R.patch(cm, { begin: 'transformed.z += sin(uTime * 3.2 + position.y * 9. + position.x * 20.) * 0.035 * (position.x + 0.08) * 6.;' });
  M.runeDecal = {};
  for (const [el, c] of Object.entries({ ember: 0xFF7A2A, tide: 0x4FB8F0, grove: 0x8CD04A, void: 0xA060FF, storm: 0xFFE070, iron: 0xE0C090 }))
    M.runeDecal[el] = new THREE.MeshBasicMaterial({ map: tex.rune, color: lin(c).multiplyScalar(1.4), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.55 });
  return M;
}
const mesh = (g, m, parent, mat4) => { const o = new THREE.Mesh(g, m); if (mat4) o.applyMatrix4(mat4); o.castShadow = true; o.receiveShadow = true; parent.add(o); return o; };
const cyl = (rt, rb, h, s = 12) => new THREE.CylinderGeometry(rt, rb, h, s);
const box = (x, y, z) => new THREE.BoxGeometry(x, y, z);

R.buildTower = function (t, tex) {
  const M = mats(tex), g = new THREE.Group(), tier = t.tier;
  g.position.set(t.x, R.groundY ? R.groundY(t.x, t.z) : 0, t.z);
  const hs = 1 + 0.14 * tier, archH = { bolt: 1, sniper: 1.22, rapid: 0.92, heavy: 0.9 }[t.arch], archW = t.arch === 'heavy' ? 1.14 : t.arch === 'sniper' ? 0.88 : 1;
  const U = g.userData = { spin: [], bob: [], flame: null, kick: 0 };
  // ---------------- plinth by rarity
  let yb;
  if (tier === 0) { for (const [x, z] of [[-0.36, -0.36], [0.36, -0.36], [-0.36, 0.36], [0.36, 0.36]]) mesh(box(0.1, 0.16, 0.1), M.wood, g, T(x, 0.08, z));
    mesh(box(0.86, 0.07, 0.86), M.wood, g, T(0, 0.19, 0)); yb = 0.22; }
  else { mesh(cyl(0.44, 0.49, 0.2, 8), M.stoneMid, g, T(0, 0.1, 0, 0, Math.PI / 8)); yb = 0.2;
    if (tier >= 2) { mesh(cyl(0.36, 0.4, 0.14, 8), M.stoneMid, g, T(0, 0.27, 0, 0, Math.PI / 8)); yb = 0.34; }
    if (tier >= 4) { mesh(cyl(0.3, 0.33, 0.1, 8), M.stoneLight, g, T(0, 0.39, 0, 0, Math.PI / 8)); yb = 0.44; }
    mesh(new THREE.TorusGeometry(0.455, 0.016, 6, 32), M.trim[tier], g, T(0, 0.2, 0, Math.PI / 2)); }
  // rarity gems: count = tier + 1, facing the camera side
  for (let k = 0; k <= tier; k++) { const a = Math.PI / 2 + (k - tier / 2) * 0.34;
    mesh(new THREE.OctahedronGeometry(0.045, 0), M.rune[tier], g, T(Math.cos(a) * 0.5, 0.12, Math.sin(a) * 0.5, 0, 0, 0, 1, 1.5, 1)); }
  // banners from Superior up
  if (tier >= 2) for (const s of [-1, 1]) { mesh(cyl(0.015, 0.015, 0.9 + tier * 0.1, 5), M.wood, g, T(s * 0.4, 0.45 + tier * 0.05, 0.34));
    const bn = mesh(new THREE.PlaneGeometry(0.16, 0.34, 1, 4), M.cloth[tier], g, T(s * 0.4 + s * 0.09, 0.72 + tier * 0.08, 0.34)); U.bob.push({ o: bn, a: 0.12, f: 2.2, ax: 'y' }); }

  // ---------------- body by element
  const hb = 1.28 * hs * archH, top = yb + hb, body = new THREE.Group(); g.add(body);
  const head = new THREE.Group(); head.position.y = top; g.add(head); U.head = head;
  switch (t.el) {
    case 'ember': {
      mesh(cyl(0.22 * archW, 0.33 * archW, hb, 6), M.basalt, body, T(0, yb + hb / 2, 0));
      for (let k = 1; k <= 2 + (tier > 2 ? 1 : 0); k++) mesh(cyl(0.3 * archW - k * 0.03, 0.31 * archW - k * 0.03, 0.025, 6), M.lava, body, T(0, yb + hb * k / (3 + (tier > 2 ? 1 : 0)), 0));
      mesh(new THREE.CylinderGeometry(0.3, 0.17, 0.18, 10, 1, true), M.iron, head, T(0, 0.06, 0));
      const fl = new THREE.Group(); fl.position.y = 0.14; head.add(fl); U.flame = fl;
      mesh(new THREE.ConeGeometry(0.17, 0.42, 7), M.flameA, fl, T(0, 0.18, 0)); mesh(new THREE.ConeGeometry(0.1, 0.34, 6), M.flameB, fl, T(0.04, 0.18, 0.03));
      for (const s of [-1, 1]) mesh(new THREE.ConeGeometry(0.07, 0.24, 5), M.flameA, fl, T(s * 0.1, 0.1, -0.04, 0, 0, -s * 0.3));
      break; }
    case 'tide': {
      mesh(cyl(0.26 * archW, 0.31 * archW, hb, 14), M.stoneLight, body, T(0, yb + hb / 2, 0));
      mesh(new THREE.ConeGeometry(0.4 * archW, 0.2, 14, 1, true), M.roofBlue, body, T(0, top - 0.08, 0));
      for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; mesh(box(0.08, 0.1, 0.08), M.stoneLight, head, T(Math.cos(a) * 0.22, 0.04, Math.sin(a) * 0.22, 0, -a)); }
      const orb = mesh(new THREE.SphereGeometry(0.15, 20, 14), M.water, head, T(0, 0.32, 0)); U.bob.push({ o: orb, a: 0.04, f: 1.6, ax: 'py', base: 0.32 });
      const ring = new THREE.Group(); ring.position.y = 0.32; head.add(ring); U.spin.push({ o: ring, s: 1.4 });
      for (let k = 0; k < 3; k++) { const a = k / 3 * Math.PI * 2; mesh(new THREE.SphereGeometry(0.035, 8, 6), M.tideG, ring, T(Math.cos(a) * 0.26, 0, Math.sin(a) * 0.26)); }
      break; }
    case 'grove': {
      mesh(cyl(0.12 * archW, 0.2 * archW, hb, 8), M.bark, body, T(0, yb + hb / 2, 0));
      for (let k = 0; k < 4; k++) { const a = k / 4 * Math.PI * 2 + 0.4; mesh(new THREE.ConeGeometry(0.07, 0.36, 5), M.bark, body, T(Math.cos(a) * 0.17, yb + 0.08, Math.sin(a) * 0.17, Math.sin(a) * 1.1, 0, -Math.cos(a) * 1.1)); }
      const can = R.merge([0, 1, 2, 3].map(k => ({ g: R.blob(1, 0.4, 300 + k + tier * 7), m: T(Math.cos(k * 1.7) * 0.18 * (k > 0), 0.12 + (k === 0) * 0.1, Math.sin(k * 1.7) * 0.18 * (k > 0), 0, 0, 0, 0.26 + (k === 0) * 0.06), c: [0x5E9A3A, 0x6EAA42, 0x4E8A34, 0x7CB84A][k], ao: [-0.2, 0.5] })));
      mesh(can, M.leaf, head, T(0, 0.08, 0));
      for (let k = 0; k < 3 + tier; k++) { const a = k * 2.4; mesh(new THREE.SphereGeometry(0.045, 8, 6), M.groveG, head, T(Math.cos(a) * 0.26, 0.02 + (k % 2) * 0.12, Math.sin(a) * 0.26)); }
      break; }
    case 'void': {
      mesh(new THREE.CylinderGeometry(0.14 * archW, 0.27 * archW, hb, 4), M.obsidian, body, T(0, yb + hb / 2, 0, 0, Math.PI / 4));
      for (let k = 0; k < 4; k++) { const a = k / 4 * Math.PI * 2; mesh(box(0.03, hb * 0.6, 0.012), M.voidG, body, T(Math.sin(a) * 0.15, yb + hb * 0.5, Math.cos(a) * 0.15, 0, a)); }
      const core = mesh(new THREE.OctahedronGeometry(0.13, 0), M.voidG, head, T(0, 0.28, 0, 0, 0, 0, 1, 1.4, 1)); U.bob.push({ o: core, a: 0.05, f: 1.2, ax: 'py', base: 0.28 });
      const orb = new THREE.Group(); orb.position.y = 0.28; head.add(orb); U.spin.push({ o: orb, s: 0.9 });
      for (let k = 0; k < 4; k++) { const a = k / 4 * Math.PI * 2; mesh(new THREE.TetrahedronGeometry(0.07, 0), M.obsidian, orb, T(Math.cos(a) * 0.28, (k % 2) * 0.08 - 0.04, Math.sin(a) * 0.28, k, k, 0)); }
      break; }
    case 'storm': {
      const n = 3; for (let k = 0; k < n; k++) mesh(cyl((0.2 - k * 0.04) * archW, (0.24 - k * 0.04) * archW, hb / n, 10), M.brass, body, T(0, yb + hb * (k + 0.5) / n, 0));
      for (let k = 0; k < 3; k++) mesh(new THREE.TorusGeometry(0.2 - k * 0.035, 0.018, 6, 20), M.copper, body, T(0, yb + hb * (0.25 + k * 0.28), 0, Math.PI / 2));
      for (let k = 0; k < 3; k++) { const a = k / 3 * Math.PI * 2; mesh(new THREE.ConeGeometry(0.025, 0.3, 5), M.copper, head, T(Math.cos(a) * 0.1, 0.12, Math.sin(a) * 0.1, Math.sin(a) * 0.35, 0, -Math.cos(a) * 0.35)); }
      const ball = mesh(new THREE.SphereGeometry(0.1, 16, 12), M.stormG, head, T(0, 0.3, 0)); U.bob.push({ o: ball, a: 0.12, f: 9, ax: 's' });
      break; }
    case 'iron': {
      const w = 0.54 * archW; mesh(box(w, hb, w), M.stoneMid, body, T(0, yb + hb / 2, 0));
      for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2, r = w / 2 - 0.04; if (k % 2) continue; mesh(box(0.1, 0.1, 0.1), M.stoneMid, body, T(Math.cos(a + Math.PI / 4) * r * 1.2, top + 0.05, Math.sin(a + Math.PI / 4) * r * 1.2)); }
      mesh(box(w + 0.02, 0.04, w + 0.02), M.brass, body, T(0, yb + hb * 0.35, 0));
      mesh(box(0.16, 0.24, 0.02), M.wood, body, T(0, yb + 0.12, w / 2 + 0.005));
      break; }
  }
  // ---------------- glowing rune band (Rare and up) and a balcony ring with posts (Superior and up)
  if (tier >= 1 && t.el !== 'grove') { const br = t.el === 'iron' ? 0.3 * archW : t.el === 'void' ? 0.2 * archW : t.el === 'storm' ? 0.2 * archW : t.el === 'tide' ? 0.3 * archW : 0.29 * archW;
    const band = mesh(new THREE.CylinderGeometry(br, br, 0.075, t.el === 'iron' || t.el === 'void' ? 4 : 28, 1, true), M.band[t.el], body, T(0, yb + hb * 0.6, 0, 0, Math.PI / 4)); }
  if (tier >= 2) { const rr = 0.36 * archW, yy = yb + hb * 0.84; mesh(new THREE.CylinderGeometry(rr, rr * 0.92, 0.05, 20), M.stoneMid, body, T(0, yy, 0));
    for (let k = 0; k < 8; k++) { const a = k / 8 * Math.PI * 2; mesh(box(0.035, 0.12, 0.035), M.iron, body, T(Math.cos(a) * rr * 0.95, yy + 0.08, Math.sin(a) * rr * 0.95)); }
    mesh(new THREE.TorusGeometry(rr * 0.95, 0.012, 5, 28), M.trim[tier], body, T(0, yy + 0.14, 0, Math.PI / 2)); }
  // ---------------- lit windows on inhabited towers; glowing rune circle on the ground under every tower
  if (t.el === 'tide' || t.el === 'iron') { const r = t.el === 'tide' ? 0.3 * archW : 0.28 * archW;
    for (let k = 0; k < 2 + (tier > 1 ? 1 : 0); k++) { const a = Math.PI / 2 + (k - 0.5) * 1.3, yy = yb + hb * (0.45 + (k % 2) * 0.25);
      mesh(box(0.06, 0.1, 0.02), M.window, body, T(Math.cos(a) * r, yy, Math.sin(a) * r, 0, -a + Math.PI / 2)); } }
  { const dec = new THREE.Mesh(new THREE.PlaneGeometry(1.25, 1.25), M.runeDecal[t.el]); dec.rotation.x = -Math.PI / 2; dec.position.y = 0.03; dec.renderOrder = 2; g.add(dec); U.spin.push({ o: dec, s: 0.25, ax: 'z' }); }
  // ---------------- archetype weapon (the head aims at targets)
  const weap = new THREE.Group(); head.add(weap); U.weapon = weap;
  const accent = { ember: M.lava, tide: M.tideG, grove: M.groveG, void: M.voidG, storm: M.stormG, iron: M.brass }[t.el];
  if (t.el === 'iron') {
    if (t.arch === 'bolt') { mesh(box(0.2, 0.1, 0.22), M.wood, weap, T(0, 0.08, 0)); mesh(cyl(0.05, 0.06, 0.4, 10), M.iron, weap, T(0, 0.16, 0.14, Math.PI / 2 - 0.15)); }
    if (t.arch === 'sniper') { mesh(box(0.08, 0.08, 0.5), M.wood, weap, T(0, 0.12, 0.05)); for (const s of [-1, 1]) mesh(box(0.34, 0.03, 0.04), M.wood, weap, T(s * 0.15, 0.13, 0.22, 0, s * 0.35)); mesh(new THREE.ConeGeometry(0.02, 0.5, 5), M.silver, weap, T(0, 0.17, 0.12, Math.PI / 2)); }
    if (t.arch === 'rapid') { mesh(cyl(0.08, 0.08, 0.14, 12), M.brass, weap, T(0, 0.12, 0, 0, 0, Math.PI / 2)); for (const s of [-1, 1]) mesh(cyl(0.025, 0.025, 0.36, 8), M.iron, weap, T(s * 0.05, 0.12, 0.2, Math.PI / 2)); }
    if (t.arch === 'heavy') { mesh(cyl(0.13, 0.16, 0.26, 12), M.iron, weap, T(0, 0.16, 0.04, -0.5)); mesh(new THREE.TorusGeometry(0.13, 0.02, 6, 16), M.brass, weap, T(0, 0.26, 0.1, Math.PI / 2 - 0.5)); }
  } else {
    if (t.arch === 'sniper') { mesh(new THREE.TorusGeometry(0.09, 0.015, 6, 18), M.trim[Math.max(1, tier)], weap, T(0, 0.3, 0.2)); mesh(new THREE.ConeGeometry(0.03, 0.2, 6), accent, weap, T(0, 0.3, 0.3, Math.PI / 2)); }
    if (t.arch === 'rapid') for (let k = 0; k < 3; k++) { const a = k / 3 * Math.PI * 2; mesh(new THREE.SphereGeometry(0.04, 8, 6), accent, weap, T(Math.cos(a) * 0.1, 0.5, Math.sin(a) * 0.1)); }
    if (t.arch === 'heavy') mesh(new THREE.TorusGeometry(0.2, 0.04, 6, 16), M.trim[Math.max(1, tier)], weap, T(0, 0.02, 0, Math.PI / 2));
  }
  // ---------------- Special: floating rune ring; Legendary: halo + orbiting gold shards
  if (tier >= 3) { const r = mesh(new THREE.TorusGeometry(0.42, 0.018, 6, 40), M.rune[tier], g, T(0, top - hb * 0.35, 0, Math.PI / 2)); U.spin.push({ o: r, s: 0.6, ax: 'z' }); }
  if (tier === 4) { const crown = new THREE.Group(); crown.position.y = top + 0.62; g.add(crown); U.spin.push({ o: crown, s: 0.9 });
    for (let k = 0; k < 6; k++) { const a = k / 6 * Math.PI * 2; mesh(new THREE.OctahedronGeometry(0.06, 0), M.gold, crown, T(Math.cos(a) * 0.3, 0, Math.sin(a) * 0.3, 0, 0, 0.3, 1, 2, 1)); }
    const halo = mesh(new THREE.TorusGeometry(0.22, 0.012, 6, 40), M.rune[4], g, T(0, top + 0.62, 0, Math.PI / 2)); }
  // ---------------- the one ability: a distinct physical prop
  if (t.ability) addAbility(g, t.ability, top, M);
  U.top = top;
  bakeStatic(g);
  return g;
};
// merge meshes that share a parent and a material into one mesh, in the parent's own space.
// Moving parts (spinning rings, bobbing orbs, the aiming weapon) stay movable: their children merge with them.
function bakeStatic(g) {
  const U = g.userData, keep = new Set();
  for (const s of U.spin) keep.add(s.o); for (const b of U.bob) keep.add(b.o);
  const parents = []; g.traverse(o => { if (o.children && o.children.length) parents.push(o); });
  for (const P of parents) {
    const groups = new Map();
    for (const o of P.children) { if (!o.isMesh || keep.has(o) || o.material.transparent) continue; const k = o.material.uuid; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(o); }
    for (const [, list] of groups) { if (list.length < 2) continue;
      let n = 0; const gs = list.map(o => { o.updateMatrix(); const q = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone(); q.applyMatrix4(o.matrix); n += q.attributes.position.count; return q; });
      const hasColor = gs.every(q => q.attributes.color);
      const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), uv = new Float32Array(n * 2), col = hasColor ? new Float32Array(n * 3) : null; let o3 = 0, o2 = 0;
      for (const q of gs) { pos.set(q.attributes.position.array, o3); nor.set(q.attributes.normal.array, o3); if (col) col.set(q.attributes.color.array, o3);
        if (q.attributes.uv) uv.set(q.attributes.uv.array, o2); o3 += q.attributes.position.count * 3; o2 += q.attributes.position.count * 2; q.dispose(); }
      const mg = new THREE.BufferGeometry(); mg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); mg.setAttribute('normal', new THREE.BufferAttribute(nor, 3)); mg.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
      if (col) mg.setAttribute('color', new THREE.BufferAttribute(col, 3));
      const mm = new THREE.Mesh(mg, list[0].material); mm.castShadow = mm.receiveShadow = true; P.add(mm);
      for (const o of list) { P.remove(o); o.geometry.dispose(); } }
  }
}
function addAbility(g, ab, top, M) {
  const a = new THREE.Group(); a.position.set(0.3, 0, 0.18); g.add(a); const U = g.userData;
  const ice = M.tideG, fire = M.flameA;
  switch (ab) {
    case 'slow': for (let k = 0; k < 3; k++) mesh(new THREE.OctahedronGeometry(0.06, 0), ice, a, T((k - 1) * 0.06, top - 0.1 - (k % 2) * 0.06, 0, 0, 0, 0, 0.8, 2.2, 0.8)); break;
    case 'burn': mesh(new THREE.CylinderGeometry(0.1, 0.06, 0.08, 10, 1, true), M.iron, a, T(0, top - 0.2, 0)); mesh(new THREE.ConeGeometry(0.06, 0.16, 6), fire, a, T(0, top - 0.1, 0)); mesh(cyl(0.012, 0.012, top - 0.2, 5), M.iron, a, T(0, (top - 0.2) / 2, 0)); break;
    case 'splash': mesh(new THREE.CylinderGeometry(0.14, 0.08, 0.06, 12, 1, true), M.brass, a, T(0, top - 0.15, 0)); mesh(new THREE.SphereGeometry(0.06, 10, 8), M.rune[2], a, T(0, top - 0.13, 0)); break;
    case 'chain': for (let k = -1; k <= 1; k++) mesh(new THREE.ConeGeometry(0.02, 0.2, 5), M.stormG, a, T(k * 0.05, top - 0.08, 0, 0, 0, -k * 0.5)); break;
    case 'pierce': mesh(new THREE.ConeGeometry(0.035, 0.46, 6), M.silver, a, T(0, top - 0.12, 0.05, Math.PI / 2)); break;
    case 'aura': { a.position.set(0, 0, 0); const r = mesh(new THREE.TorusGeometry(0.6, 0.02, 6, 48), M.rune[2], a, T(0, 0.06, 0, Math.PI / 2)); U.spin.push({ o: r, s: 0.5, ax: 'z' }); break; }
    case 'skyward': for (const s of [-1, 1]) mesh(new THREE.ConeGeometry(0.05, 0.26, 4), M.silver, a, T(s * 0.05, top - 0.05, 0, 0, 0, s * 0.3)); break;
    case 'shred': { const d = mesh(cyl(0.12, 0.12, 0.02, 8), M.silver, a, T(0, top - 0.12, 0, 0, 0, Math.PI / 2)); U.spin.push({ o: d, s: 10, ax: 'y' }); break; }
  }
}
R.animateTower = function (g, dt, time, reduced) {
  const U = g.userData; if (reduced) return; const kick = U.kick || 0;
  if (U.weapon) { const yw = U.weapon.rotation.y; U.weapon.position.set(-Math.sin(yw) * kick * 0.07, 0, -Math.cos(yw) * kick * 0.07); }
  for (const s of U.spin) { if (s.ax === 'z') s.o.rotation.z += dt * s.s; else s.o.rotation.y += dt * s.s; }
  for (const b of U.bob) { if (b.ax === 'py') b.o.position.y = b.base + Math.sin(time * b.f) * b.a; else if (b.ax === 's') b.o.scale.setScalar(1 + Math.sin(time * b.f) * b.a * Math.random()); else b.o.rotation.y = Math.sin(time * b.f) * b.a; }
  if (U.flame) { const f = 1 + Math.sin(time * 13) * 0.08 + Math.sin(time * 7.3) * 0.06 + kick * 0.45; U.flame.scale.set(1 / f + kick * 0.2, f, 1 / f + kick * 0.2); }
  for (const b of U.bob) if (b.ax === 'py') b.o.scale.setScalar(1 + kick * 0.35);
  for (const s of U.spin) if (!s.ax) s.o.rotation.y += dt * s.s * kick * 4;
};
})();
